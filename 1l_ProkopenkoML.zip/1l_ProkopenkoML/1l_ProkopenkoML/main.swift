//
//  main.swift
//  1l_ProkopenkoML
//
//  Created by Максим Прокопенко on 09.09.2021.
//



//1. Решить квадратное уравнение.

var a = 1.0
var b = -6.0
var c = 9.0

var x1 = 0.0
var x2 = 0.0

var D = pow(b, 2)-4*a*c

if (D<0)
{
    print("Корней нет")
}
if (D==0)
{
    x1 = (-b+sqrt(D))/(2*a)
}
if (D>0)
{
    x1 = (-b+sqrt(D))/(2*a)
    x2 = (-b-sqrt(D))/(2*a)
}



//2. Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.
var leg1 = 6.0
var leg2 = 4.0

var S = 0.0
var P = 0.0
var hypotenuse = 0.0

hypotenuse = sqrt(pow(leg1, 2)+pow(leg2, 2))
P = leg1+leg2+hypotenuse
S = (leg1*leg2)/2

//3. * Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.
var contribution = 6000.0
var percent = 10
var years = 5
var Y = 0.0

Y = Double((Int(contribution)*percent*years)/100)+contribution
